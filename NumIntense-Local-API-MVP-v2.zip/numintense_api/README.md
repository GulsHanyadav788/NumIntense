# NumIntense Local Intelligence API — MVP 0.2

Free, local-first domain investigation dashboard. Uses Python standard library only.


## Run

```bash
python3 local_api.py
```
Open `http://127.0.0.1:8765` on the same device. Works on compatible Python 3 installations, including Termux.


## Modules
- DNS A/AAAA lookup via the device resolver
- Domain RDAP summary via the public `rdap.org` bootstrap endpoint
- IP RDAP summary (network/ASN registry metadata, depending on returned registry data)
- TLS certificate handshake/summary (TLS version, cipher, validity dates, SANs)
- Small relationship graph (domain → IP → registered network label)
- `/api/health`
- `POST /api/investigate/domain` DNS-only JSON API
- `POST /api/investigate/full` full public-metadata scan JSON API


## Free data and limitations
- No paid APIs and no extra pip dependencies.
- RDAP requires internet access and sends the query domain/IP to rdap.org and the registry it redirects to.
- TLS probing requires internet access and attempts a public IP on TCP/443. Private/reserved targets are filtered.
- DNS uses the phone/device resolver. DNS and RDAP may fail offline, rate-limit, or return incomplete results.
- IP RDAP often provides network registration metadata, but does not guarantee an ASN field in all registries.
- No personal identity lookup, contact details extraction, exploitation, or malware verdict. Only investigate systems you have permission to assess.
- This MVP is not yet integrated into the upstream GitHub repo because this chat's GitHub connector rejected branch/file writes (HTTP 403); GitHub network clone is unavailable in this environment. This package contains the code for import/manual integration.
