#!/usr/bin/env python3
"""NumIntense free local-first public infrastructure investigation API."""
import ipaddress, json, re, socket, ssl, urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST, PORT = "127.0.0.1", 8765
ROOT = Path(__file__).resolve().parent
DOMAIN_RE = re.compile(r"^(?=.{1,253}$)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}$")
UA = "NumIntense/0.2 (public RDAP investigation; user-triggered)"

def now(): return datetime.now(timezone.utc).isoformat()
def valid_domain(value):
    d = str(value).strip().rstrip(".").lower()
    if not DOMAIN_RE.fullmatch(d): raise ValueError("Enter a valid domain name, e.g. example.com")
    if d == "localhost" or d.endswith((".local", ".localhost")): raise ValueError("Local-only names are not supported")
    return d

def public_ip(value):
    ip = ipaddress.ip_address(value)
    if not ip.is_global: raise ValueError("Private, loopback, link-local or reserved IP blocked")
    return str(ip)

def dns_lookup(domain):
    records, errors = {}, {}
    for family, typ in ((socket.AF_INET, "A"), (socket.AF_INET6, "AAAA")):
        try:
            rows = socket.getaddrinfo(domain, None, family, socket.SOCK_STREAM)
            ips = sorted({row[4][0] for row in rows})
            if any(not ipaddress.ip_address(ip).is_global for ip in ips):
                records[typ] = []; errors[typ] = "Non-public address result filtered"
            else: records[typ] = ips
        except socket.gaierror as exc: records[typ] = []; errors[typ] = str(exc)
    return records, errors

def rdap_lookup(kind, value):
    # rdap.org is a free bootstrap service; user-submitted queries are sent to it.
    url = f"https://rdap.org/{kind}/{value}"
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/rdap+json, application/json"})
    try:
        with urllib.request.urlopen(req, timeout=9) as resp:
            raw = json.loads(resp.read(900_000))
        # Extract a compact, non-sensitive registration summary; do not expose contact details.
        summary = {"query": value, "source": url, "object_class": raw.get("objectClassName"),
                  "name": raw.get("name") or raw.get("handle"), "status": raw.get("status", []),
                  "country": raw.get("country"), "start_date": raw.get("startDate"),
                  "end_date": raw.get("endDate"), "events": [{"action": e.get("eventAction"), "date": e.get("eventDate")} for e in raw.get("events", [])[:6]],
                  "entities_summary": [e.get("roles", []) for e in raw.get("entities", [])[:8]]}
        # For IP RDAP, include common network fields.
        if kind == "ip":
            for key in ("startAddress", "endAddress", "ipVersion", "type", "port43", "parentHandle"):
                if key in raw: summary[key] = raw[key]
        return {"ok": True, "data": summary}
    except Exception as exc:
        return {"ok": False, "error": str(exc)[:220], "source": url}

def tls_probe(domain, port=443):
    out = {"host": domain, "port": port, "checked_at": now()}
    try:
        # Resolve first and refuse non-public results to reduce local-network probing.
        addresses = socket.getaddrinfo(domain, port, socket.AF_UNSPEC, socket.SOCK_STREAM)
        public = sorted({row[4][0] for row in addresses if ipaddress.ip_address(row[4][0]).is_global})
        if not public: return {**out, "ok": False, "error": "No public IP address available; TLS probe skipped"}
        context = ssl.create_default_context()
        with socket.create_connection((public[0], port), timeout=5) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as tls:
                cert = tls.getpeercert()
                out.update({"ok": True, "tls_version": tls.version(), "cipher": tls.cipher()[0] if tls.cipher() else None,
                           "subject": cert.get("subject", []), "issuer": cert.get("issuer", []),
                           "not_before": cert.get("notBefore"), "not_after": cert.get("notAfter"),
                           "subject_alt_names": [x[1] for x in cert.get("subjectAltName", [])][:30]})
    except Exception as exc: out.update({"ok": False, "error": str(exc)[:220]})
    return out

def investigate_domain(value, full=False):
    domain = valid_domain(value)
    records, errors = dns_lookup(domain)
    ips = sorted({ip for group in records.values() for ip in group})[:6]
    result = {"domain": domain, "records": records, "lookup_errors": errors,
              "source": "Device DNS resolver", "checked_at": now(),
              "note": "Public metadata only. Results are snapshots, not proof of ownership or maliciousness."}
    if full:
        result["rdap_domain"] = rdap_lookup("domain", domain)
        result["ip_details"] = {ip: rdap_lookup("ip", ip) for ip in ips[:3]}
        result["tls"] = tls_probe(domain)
        nodes, edges = [{"id": domain, "type": "domain", "label": domain}], []
        for ip in ips:
            nodes.append({"id": ip, "type": "ip", "label": ip}); edges.append({"from": domain, "to": ip, "type": "resolves_to"})
            ipdata = result["ip_details"].get(ip, {}).get("data", {})
            if ipdata.get("name"):
                n = ipdata["name"]
                nodes.append({"id": "net:"+n, "type": "network", "label": n}); edges.append({"from": ip, "to": "net:"+n, "type": "registered_to"})
        result["graph"] = {"nodes": nodes, "edges": edges}
    return result

class Handler(BaseHTTPRequestHandler):
    def send_json(self, code, payload):
        body = json.dumps(payload).encode(); self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        if self.path == "/api/health": return self.send_json(200, {"ok": True, "service": "NumIntense Local API", "version": "0.2.0", "modules": ["DNS", "RDAP", "IP/ASN metadata", "TLS"]})
        if self.path in ("/", "/index.html"):
            try:
                data = (ROOT / "web" / "index.html").read_bytes(); self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
            except OSError: self.send_json(404, {"error": "Dashboard missing. Ensure web/index.html exists."})
            return
        return self.send_json(404, {"error": "Route not found"})
    def do_POST(self):
        routes = {"/api/investigate/domain": False, "/api/investigate/full": True}
        if self.path not in routes: return self.send_json(404, {"error": "Route not found"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 2048: return self.send_json(400, {"error": "Request size invalid"})
            payload = json.loads(self.rfile.read(length)); domain = payload.get("domain", "")
            return self.send_json(200, investigate_domain(domain, full=routes[self.path]))
        except (ValueError, TypeError, json.JSONDecodeError) as exc: return self.send_json(400, {"error": str(exc) or "Invalid JSON"})
        except Exception: return self.send_json(500, {"error": "Unexpected server error"})
    def log_message(self, fmt, *args): print("[NumIntense]", fmt % args)

if __name__ == "__main__":
    print(f"NumIntense Local API running at http://{HOST}:{PORT}")
    print("Local-only binding. Stop with Ctrl+C.")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
